# Mehdi's Kitchen 🍽️

Your personal recipe book & weekly meal planner.

## Deploy to Vercel (Free, 5 minutes)

1. Go to **vercel.com** and sign up for free
2. Click **"Add New Project"**
3. Click **"Upload"** and drag this entire folder
4. Click **Deploy** — done!

You'll get a URL like `mehdis-kitchen.vercel.app`

## Add to your iPhone Home Screen

1. Open your Vercel URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add** — it'll appear as an app icon!

## Admin Mode

- Tap **"Admin"** in the top right
- Enter PIN: **1234**
- You can now add, edit, and delete recipes

## Changing your PIN

Open `src/App.js` and change the `ADMIN_PIN` value at the top.

