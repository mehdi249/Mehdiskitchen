import React, { useState, useEffect } from "react";
import { INITIAL_RECIPES, DAYS, CUISINE_OPTIONS, TAG_OPTIONS, TYPE_OPTIONS, CUISINE_COLORS, TAG_COLORS } from "./data";

const ADMIN_PIN = "1234";

function useRecipes() {
  const [recipes, setRecipes] = useState(() => {
    try {
      const s = localStorage.getItem("mk-recipes");
      return s ? JSON.parse(s) : INITIAL_RECIPES;
    } catch { return INITIAL_RECIPES; }
  });
  useEffect(() => {
    try { localStorage.setItem("mk-recipes", JSON.stringify(recipes)); } catch {}
  }, [recipes]);
  const addRecipe = (r) => setRecipes(p => [...p, { ...r, id: Date.now().toString() }]);
  const updateRecipe = (r) => setRecipes(p => p.map(x => x.id === r.id ? r : x));
  const deleteRecipe = (id) => setRecipes(p => p.filter(x => x.id !== id));
  return { recipes, addRecipe, updateRecipe, deleteRecipe };
}

export default function App() {
  const { recipes, addRecipe, updateRecipe, deleteRecipe } = useRecipes();
  const [view, setView] = useState("gallery");
  const [selected, setSelected] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [filterCuisine, setFilterCuisine] = useState("All");
  const [filterTag, setFilterTag] = useState("All");

  const cuisines = ["All", ...new Set(recipes.map(r => r.cuisine).filter(Boolean))];
  const tags = ["All", ...new Set(recipes.flatMap(r => r.tags || []))];
  const filtered = recipes.filter(r => {
    const cm = filterCuisine === "All" || r.cuisine === filterCuisine;
    const tm = filterTag === "All" || (r.tags || []).includes(filterTag);
    return cm && tm;
  });

  const openRecipe = (r) => { setSelected(r); setView("detail"); };
  const goBack = () => { setSelected(null); setView("gallery"); };

  const handleAdminToggle = () => {
    if (isAdmin) { setIsAdmin(false); setShowEditor(false); }
    else setShowPinModal(true);
  };
  const handlePinSuccess = () => { setIsAdmin(true); setShowPinModal(false); };

  const openEditor = (recipe = null) => {
    setEditingRecipe(recipe);
    setShowEditor(true);
  };
  const handleSave = (recipe) => {
    if (recipe.id) updateRecipe(recipe);
    else addRecipe(recipe);
    setShowEditor(false);
    setEditingRecipe(null);
  };
  const handleDelete = (id) => {
    if (window.confirm("Delete this recipe?")) {
      deleteRecipe(id);
      if (selected?.id === id) goBack();
    }
  };

  return (
    <div style={s.root}>
      {/* PIN MODAL */}
      {showPinModal && <PinModal onSuccess={handlePinSuccess} onClose={() => setShowPinModal(false)} />}

      {/* EDITOR MODAL */}
      {showEditor && (
        <RecipeEditor
          recipe={editingRecipe}
          onSave={handleSave}
          onClose={() => { setShowEditor(false); setEditingRecipe(null); }}
        />
      )}

      {/* HEADER */}
      <header style={s.header}>
        <div style={s.headerInner}>
          <div style={s.logo} onClick={goBack}>
            <span style={s.logoMark}>✦</span>
            <span style={s.logoText}>Mehdi's Kitchen</span>
          </div>
          <nav style={s.nav}>
            <NavBtn active={view === "gallery" || view === "detail"} onClick={goBack}>Recipes</NavBtn>
            <NavBtn active={view === "planner"} onClick={() => { setView("planner"); setSelected(null); }}>Weekly Plan</NavBtn>
            <button onClick={handleAdminToggle} style={{ ...s.adminBtn, ...(isAdmin ? s.adminBtnActive : {}) }}>
              {isAdmin ? "✦ Admin" : "Admin"}
            </button>
          </nav>
        </div>
        {isAdmin && (
          <div style={s.adminBar}>
            <span style={s.adminBarLabel}>Admin Mode</span>
            <button onClick={() => openEditor(null)} style={s.addBtn}>+ Add Recipe</button>
          </div>
        )}
      </header>

      <main style={s.main}>
        {/* GALLERY */}
        {view === "gallery" && (
          <div>
            <div style={s.filtersRow}>
              <FilterGroup label="Cuisine" options={cuisines} active={filterCuisine} onChange={setFilterCuisine} colors={CUISINE_COLORS} />
              <FilterGroup label="Tags" options={tags} active={filterTag} onChange={setFilterTag} />
            </div>
            <p style={s.count}>{filtered.length} recipe{filtered.length !== 1 ? "s" : ""}</p>
            <div style={s.grid}>
              {filtered.map(r => (
                <RecipeCard
                  key={r.id} recipe={r}
                  onClick={() => openRecipe(r)}
                  isAdmin={isAdmin}
                  onEdit={() => openEditor(r)}
                  onDelete={() => handleDelete(r.id)}
                />
              ))}
              {isAdmin && (
                <div onClick={() => openEditor(null)} style={s.addCard}>
                  <span style={s.addCardPlus}>+</span>
                  <span style={s.addCardLabel}>Add Recipe</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* DETAIL */}
        {view === "detail" && selected && (
          <RecipeDetail
            recipe={selected} onBack={goBack}
            isAdmin={isAdmin}
            onEdit={() => openEditor(selected)}
            onDelete={() => handleDelete(selected.id)}
          />
        )}

        {/* PLANNER */}
        {view === "planner" && (
          <WeeklyPlanner recipes={recipes} onRecipeClick={openRecipe} isAdmin={isAdmin} onEdit={openEditor} />
        )}
      </main>
    </div>
  );
}

/* ── COMPONENTS ─────────────────────────────────────────── */

function NavBtn({ active, onClick, children }) {
  return (
    <button onClick={onClick} style={{ ...s.navBtn, ...(active ? s.navBtnActive : {}) }}>
      {children}
    </button>
  );
}

function FilterGroup({ label, options, active, onChange, colors = {} }) {
  return (
    <div style={s.filterGroup}>
      <span style={s.filterLabel}>{label}</span>
      <div style={s.pills}>
        {options.map(o => (
          <button key={o} onClick={() => onChange(o)} style={{
            ...s.pill,
            ...(active === o ? s.pillActive : {}),
            ...(active === o && o !== "All" && colors[o] ? { background: colors[o], borderColor: colors[o], color: "#fff" } : {})
          }}>{o}</button>
        ))}
      </div>
    </div>
  );
}

function RecipeCard({ recipe, onClick, isAdmin, onEdit, onDelete }) {
  const [hovered, setHovered] = useState(false);
  const [imgErr, setImgErr] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ ...s.card, transform: hovered ? "translateY(-6px)" : "none", boxShadow: hovered ? "0 24px 60px rgba(0,0,0,0.6)" : "0 4px 20px rgba(0,0,0,0.3)" }}
    >
      <div style={s.cardImgWrap} onClick={onClick}>
        {recipe.image && !imgErr
          ? <img src={recipe.image} alt={recipe.name} style={{ ...s.cardImg, transform: hovered ? "scale(1.07)" : "scale(1)" }} onError={() => setImgErr(true)} />
          : <div style={s.cardImgFallback}><span style={{ fontSize: 48 }}>🍽️</span></div>
        }
        <div style={s.cardImgOverlay} />
        {recipe.cuisine && <span style={{ ...s.badge, background: CUISINE_COLORS[recipe.cuisine] || "#888" }}>{recipe.cuisine}</span>}
      </div>
      <div style={s.cardBody}>
        <h3 style={s.cardTitle} onClick={onClick}>{recipe.name}</h3>
        <div style={s.cardMeta}>
          {(recipe.tags || []).map(t => <span key={t} style={{ ...s.tag, background: TAG_COLORS[t] || "#555" }}>{t}</span>)}
        </div>
        <div style={s.cardFooter}>
          <div style={s.cardDays}>
            {(recipe.schedule || []).map(d => <span key={d} style={s.dayPill}>{d.slice(0, 3)}</span>)}
          </div>
          {isAdmin && (
            <div style={s.cardAdminBtns}>
              <button onClick={onEdit} style={s.iconBtn}>✎</button>
              <button onClick={onDelete} style={{ ...s.iconBtn, color: "#e85a5a" }}>✕</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function RecipeDetail({ recipe, onBack, isAdmin, onEdit, onDelete }) {
  const [imgErr, setImgErr] = useState(false);
  return (
    <div style={s.detail}>
      <div style={s.detailTopBar}>
        <button onClick={onBack} style={s.backBtn}>← Back</button>
        {isAdmin && (
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={onEdit} style={s.editBtn}>✎ Edit Recipe</button>
            <button onClick={onDelete} style={{ ...s.editBtn, color: "#e85a5a", borderColor: "#e85a5a" }}>✕ Delete</button>
          </div>
        )}
      </div>

      <div style={s.hero}>
        {recipe.image && !imgErr
          ? <img src={recipe.image} alt={recipe.name} style={s.heroImg} onError={() => setImgErr(true)} />
          : <div style={{ ...s.heroImg, background: "#1a1a1a", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ fontSize: 80 }}>🍽️</span></div>
        }
        <div style={s.heroOverlay} />
        <div style={s.heroContent}>
          {recipe.cuisine && <span style={{ ...s.badge, background: CUISINE_COLORS[recipe.cuisine] || "#888", marginBottom: 12, display: "inline-block", position: "relative" }}>{recipe.cuisine}</span>}
          <h1 style={s.detailTitle}>{recipe.name}</h1>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
            {(recipe.tags || []).map(t => <span key={t} style={{ ...s.tag, background: TAG_COLORS[t] || "#555" }}>{t}</span>)}
            {(recipe.schedule || []).map(d => <span key={d} style={s.dayPill}>{d}</span>)}
          </div>
        </div>
      </div>

      {recipe.macros && (
        <div style={s.macrosRow}>
          {Object.entries(recipe.macros).map(([k, v]) => (
            <div key={k} style={s.macroBox}>
              <span style={s.macroVal}>{v}{k !== "calories" ? "g" : ""}</span>
              <span style={s.macroKey}>{k.charAt(0).toUpperCase() + k.slice(1)}</span>
            </div>
          ))}
        </div>
      )}

      <div style={s.detailBody}>
        <div>
          <h2 style={s.sectionTitle}>Ingredients</h2>
          {Object.entries(recipe.ingredients || {}).map(([sec, items]) => (
            <div key={sec} style={{ marginBottom: 28 }}>
              <h3 style={s.ingredientSec}>{sec}</h3>
              <ul style={s.ingredientList}>
                {items.map((item, i) => (
                  <li key={i} style={s.ingredientItem}>
                    <span style={s.ingredientDot}>✦</span>{item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div>
          <h2 style={s.sectionTitle}>Method</h2>
          <ol style={s.stepList}>
            {(recipe.steps || []).map((step, i) => (
              <li key={i} style={s.stepItem}>
                <span style={s.stepNum}>{String(i + 1).padStart(2, "0")}</span>
                <span style={s.stepText}>{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}

function WeeklyPlanner({ recipes, onRecipeClick, isAdmin, onEdit }) {
  return (
    <div>
      <h2 style={s.plannerTitle}>This Week</h2>
      <div style={s.plannerGrid}>
        {DAYS.map(day => {
          const dayRecipes = recipes.filter(r => (r.schedule || []).includes(day));
          return (
            <div key={day} style={s.dayCol}>
              <div style={s.dayHeader}>
                <span style={s.dayName}>{day}</span>
                <span style={s.dayCount}>{dayRecipes.length > 0 ? `${dayRecipes.length} meal${dayRecipes.length > 1 ? "s" : ""}` : "—"}</span>
              </div>
              {dayRecipes.length === 0
                ? <div style={s.emptyDay}>No meals planned</div>
                : dayRecipes.map(r => (
                  <PlannerCard key={r.id} recipe={r} onClick={() => onRecipeClick(r)} isAdmin={isAdmin} onEdit={() => onEdit(r)} />
                ))
              }
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PlannerCard({ recipe, onClick, isAdmin, onEdit }) {
  const [imgErr, setImgErr] = useState(false);
  const [hovered, setHovered] = useState(false);
  return (
    <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} style={{ ...s.plannerCard, borderColor: hovered ? "#333" : "#1a1a1a" }}>
      <div style={s.plannerImgWrap} onClick={onClick}>
        {recipe.image && !imgErr
          ? <img src={recipe.image} alt={recipe.name} style={s.plannerImg} onError={() => setImgErr(true)} />
          : <div style={{ ...s.plannerImg, background: "#1a1a1a", display: "flex", alignItems: "center", justifyContent: "center" }}><span>🍽️</span></div>
        }
        <div style={s.plannerImgOverlay} />
      </div>
      <div style={s.plannerBody}>
        <p style={s.plannerName} onClick={onClick}>{recipe.name}</p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {recipe.cuisine && <span style={{ ...s.badge, fontSize: 10, padding: "2px 8px", position: "relative", background: CUISINE_COLORS[recipe.cuisine] || "#888" }}>{recipe.cuisine}</span>}
          {isAdmin && <button onClick={onEdit} style={{ ...s.iconBtn, fontSize: 11 }}>✎</button>}
        </div>
      </div>
    </div>
  );
}

/* ── ADMIN: PIN MODAL ───────────────────────────────────── */

function PinModal({ onSuccess, onClose }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);
  const handleSubmit = () => {
    if (pin === ADMIN_PIN) onSuccess();
    else { setError(true); setPin(""); setTimeout(() => setError(false), 1500); }
  };
  return (
    <div style={s.modalOverlay}>
      <div style={s.modal}>
        <h2 style={s.modalTitle}>Admin Access</h2>
        <p style={s.modalSub}>Enter your PIN to continue</p>
        <input
          type="password" maxLength={4} value={pin}
          onChange={e => setPin(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleSubmit()}
          placeholder="••••"
          style={{ ...s.pinInput, ...(error ? { borderColor: "#e85a5a" } : {}) }}
          autoFocus
        />
        {error && <p style={s.pinError}>Incorrect PIN</p>}
        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          <button onClick={onClose} style={s.modalCancelBtn}>Cancel</button>
          <button onClick={handleSubmit} style={s.modalConfirmBtn}>Enter</button>
        </div>
      </div>
    </div>
  );
}

/* ── ADMIN: RECIPE EDITOR ───────────────────────────────── */

function RecipeEditor({ recipe, onSave, onClose }) {
  const isNew = !recipe;
  const [form, setForm] = useState(recipe || {
    name: "", cuisine: "", tags: [], type: "Main Course",
    schedule: [], image: "", ingredients: { "": [""] }, steps: [""]
  });

  const set = (key, val) => setForm(p => ({ ...p, [key]: val }));

  // Ingredients helpers
  const addSection = () => {
    set("ingredients", { ...form.ingredients, "New Section": [""] });
  };
  const renameSection = (oldKey, newKey) => {
    const entries = Object.entries(form.ingredients);
    const idx = entries.findIndex(([k]) => k === oldKey);
    entries[idx] = [newKey, entries[idx][1]];
    set("ingredients", Object.fromEntries(entries));
  };
  const removeSection = (key) => {
    const next = { ...form.ingredients };
    delete next[key];
    set("ingredients", next);
  };
  const addIngredient = (sec) => set("ingredients", { ...form.ingredients, [sec]: [...form.ingredients[sec], ""] });
  const updateIngredient = (sec, i, val) => {
    const list = [...form.ingredients[sec]];
    list[i] = val;
    set("ingredients", { ...form.ingredients, [sec]: list });
  };
  const removeIngredient = (sec, i) => {
    const list = form.ingredients[sec].filter((_, idx) => idx !== i);
    set("ingredients", { ...form.ingredients, [sec]: list });
  };

  // Steps helpers
  const addStep = () => set("steps", [...(form.steps || []), ""]);
  const updateStep = (i, val) => { const s = [...form.steps]; s[i] = val; set("steps", s); };
  const removeStep = (i) => set("steps", form.steps.filter((_, idx) => idx !== i));

  const toggleTag = (t) => set("tags", (form.tags || []).includes(t) ? form.tags.filter(x => x !== t) : [...(form.tags || []), t]);
  const toggleDay = (d) => set("schedule", (form.schedule || []).includes(d) ? form.schedule.filter(x => x !== d) : [...(form.schedule || []), d]);

  const handleSave = () => {
    if (!form.name.trim()) return alert("Recipe name is required");
    onSave(form);
  };

  return (
    <div style={s.modalOverlay}>
      <div style={{ ...s.modal, width: "min(780px, 95vw)", maxHeight: "90vh", overflowY: "auto", padding: 0 }}>
        {/* Editor Header */}
        <div style={s.editorHeader}>
          <h2 style={s.modalTitle}>{isNew ? "New Recipe" : "Edit Recipe"}</h2>
          <button onClick={onClose} style={s.closeBtn}>✕</button>
        </div>

        <div style={s.editorBody}>
          {/* Basic Info */}
          <Section title="Basic Info">
            <Label>Recipe Name *</Label>
            <input style={s.input} value={form.name} onChange={e => set("name", e.target.value)} placeholder="e.g. Chipotle Honey Chicken Tacos" />

            <Label>Image URL</Label>
            <input style={s.input} value={form.image || ""} onChange={e => set("image", e.target.value)} placeholder="https://example.com/image.jpg" />
            {form.image && <img src={form.image} alt="preview" style={s.imgPreview} onError={e => e.target.style.display = "none"} />}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div>
                <Label>Cuisine</Label>
                <select style={s.select} value={form.cuisine || ""} onChange={e => set("cuisine", e.target.value)}>
                  <option value="">Select cuisine</option>
                  {CUISINE_OPTIONS.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <Label>Type</Label>
                <select style={s.select} value={form.type || ""} onChange={e => set("type", e.target.value)}>
                  {TYPE_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
          </Section>

          {/* Tags */}
          <Section title="Tags">
            <div style={s.checkGrid}>
              {TAG_OPTIONS.map(t => (
                <label key={t} style={s.checkLabel}>
                  <input type="checkbox" checked={(form.tags || []).includes(t)} onChange={() => toggleTag(t)} style={{ accentColor: "#c8a96e" }} />
                  {t}
                </label>
              ))}
            </div>
          </Section>

          {/* Schedule */}
          <Section title="Schedule">
            <div style={s.checkGrid}>
              {DAYS.map(d => (
                <label key={d} style={s.checkLabel}>
                  <input type="checkbox" checked={(form.schedule || []).includes(d)} onChange={() => toggleDay(d)} style={{ accentColor: "#c8a96e" }} />
                  {d}
                </label>
              ))}
            </div>
          </Section>

          {/* Ingredients */}
          <Section title="Ingredients">
            {Object.entries(form.ingredients || {}).map(([sec, items]) => (
              <div key={sec} style={s.ingredientBlock}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                  <input
                    style={{ ...s.input, marginBottom: 0, flex: 1, fontStyle: "italic" }}
                    value={sec}
                    onChange={e => renameSection(sec, e.target.value)}
                    placeholder="Section name"
                  />
                  <button onClick={() => removeSection(sec)} style={{ ...s.iconBtn, color: "#e85a5a", fontSize: 16 }}>✕</button>
                </div>
                {items.map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                    <input
                      style={{ ...s.input, marginBottom: 0, flex: 1 }}
                      value={item}
                      onChange={e => updateIngredient(sec, i, e.target.value)}
                      placeholder="e.g. 2 tbsp olive oil"
                    />
                    <button onClick={() => removeIngredient(sec, i)} style={{ ...s.iconBtn, color: "#666", fontSize: 16 }}>✕</button>
                  </div>
                ))}
                <button onClick={() => addIngredient(sec)} style={s.ghostBtn}>+ Add ingredient</button>
              </div>
            ))}
            <button onClick={addSection} style={s.ghostBtn}>+ Add section</button>
          </Section>

          {/* Steps */}
          <Section title="Method">
            {(form.steps || []).map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "flex-start" }}>
                <span style={{ ...s.stepNum, fontSize: 20, minWidth: 28, color: "#333" }}>{String(i + 1).padStart(2, "0")}</span>
                <textarea
                  style={{ ...s.input, marginBottom: 0, flex: 1, minHeight: 60, resize: "vertical" }}
                  value={step}
                  onChange={e => updateStep(i, e.target.value)}
                  placeholder={`Step ${i + 1}`}
                />
                <button onClick={() => removeStep(i)} style={{ ...s.iconBtn, color: "#666", fontSize: 16, marginTop: 4 }}>✕</button>
              </div>
            ))}
            <button onClick={addStep} style={s.ghostBtn}>+ Add step</button>
          </Section>
        </div>

        {/* Editor Footer */}
        <div style={s.editorFooter}>
          <button onClick={onClose} style={s.modalCancelBtn}>Cancel</button>
          <button onClick={handleSave} style={s.modalConfirmBtn}>{isNew ? "Add Recipe" : "Save Changes"}</button>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={s.editorSection}>
      <h3 style={s.editorSectionTitle}>{title}</h3>
      {children}
    </div>
  );
}

function Label({ children }) {
  return <label style={s.label}>{children}</label>;
}

/* ── STYLES ─────────────────────────────────────────────── */
const s = {
  root: { minHeight: "100vh", background: "#0d0d0d", color: "#f0ede8", fontFamily: "'Cormorant Garamond', Georgia, serif" },
  header: { borderBottom: "1px solid #1a1a1a", position: "sticky", top: 0, zIndex: 100, background: "rgba(13,13,13,0.95)", backdropFilter: "blur(12px)" },
  headerInner: { maxWidth: 1200, margin: "0 auto", padding: "0 24px", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" },
  logo: { display: "flex", alignItems: "center", gap: 10, cursor: "pointer" },
  logoMark: { color: "#c8a96e", fontSize: 16 },
  logoText: { fontSize: 20, letterSpacing: "0.06em", fontWeight: 400 },
  nav: { display: "flex", gap: 4, alignItems: "center" },
  navBtn: { background: "none", border: "none", color: "#666", fontSize: 14, cursor: "pointer", padding: "8px 14px", borderRadius: 6, fontFamily: "inherit", letterSpacing: "0.04em", transition: "all 0.2s" },
  navBtnActive: { color: "#f0ede8", background: "#1a1a1a" },
  adminBtn: { background: "none", border: "1px solid #2a2a2a", color: "#666", fontSize: 12, cursor: "pointer", padding: "6px 14px", borderRadius: 100, fontFamily: "sans-serif", letterSpacing: "0.08em", marginLeft: 8, transition: "all 0.2s" },
  adminBtnActive: { borderColor: "#c8a96e", color: "#c8a96e", background: "rgba(200,169,110,0.08)" },
  adminBar: { background: "rgba(200,169,110,0.06)", borderTop: "1px solid rgba(200,169,110,0.15)", padding: "8px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: "100%" },
  adminBarLabel: { fontSize: 12, color: "#c8a96e", letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "sans-serif" },
  addBtn: { background: "#c8a96e", border: "none", color: "#0d0d0d", fontSize: 13, cursor: "pointer", padding: "6px 16px", borderRadius: 6, fontFamily: "sans-serif", fontWeight: 600 },
  main: { maxWidth: 1200, margin: "0 auto", padding: "40px 24px" },
  filtersRow: { display: "flex", gap: 32, flexWrap: "wrap", marginBottom: 32 },
  filterGroup: { display: "flex", flexDirection: "column", gap: 10 },
  filterLabel: { fontSize: 11, letterSpacing: "0.15em", color: "#555", textTransform: "uppercase", fontFamily: "sans-serif" },
  pills: { display: "flex", gap: 8, flexWrap: "wrap" },
  pill: { background: "none", border: "1px solid #222", color: "#666", fontSize: 13, padding: "5px 14px", borderRadius: 100, cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.03em", transition: "all 0.2s" },
  pillActive: { color: "#f0ede8", borderColor: "#f0ede8", background: "#1a1a1a" },
  count: { fontSize: 11, color: "#444", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 24, fontFamily: "sans-serif" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 24 },
  card: { background: "#111", borderRadius: 12, overflow: "hidden", cursor: "pointer", transition: "all 0.3s cubic-bezier(0.34,1.56,0.64,1)", border: "1px solid #1a1a1a" },
  cardImgWrap: { position: "relative", height: 220, overflow: "hidden" },
  cardImg: { width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.5s ease" },
  cardImgFallback: { width: "100%", height: "100%", background: "#1a1a1a", display: "flex", alignItems: "center", justifyContent: "center" },
  cardImgOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.65) 0%, transparent 55%)" },
  badge: { position: "absolute", top: 12, left: 12, fontSize: 11, padding: "3px 10px", borderRadius: 100, color: "#fff", letterSpacing: "0.08em", fontFamily: "sans-serif", textTransform: "uppercase", fontWeight: 600 },
  cardBody: { padding: "16px 18px 18px" },
  cardTitle: { fontSize: 16, fontWeight: 400, margin: "0 0 10px", lineHeight: 1.4, color: "#f0ede8", cursor: "pointer" },
  cardMeta: { display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 },
  tag: { fontSize: 11, padding: "3px 8px", borderRadius: 4, color: "#fff", letterSpacing: "0.04em", fontFamily: "sans-serif" },
  cardFooter: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  cardDays: { display: "flex", gap: 6, flexWrap: "wrap" },
  dayPill: { fontSize: 11, padding: "3px 10px", borderRadius: 100, background: "#1a1a1a", color: "#666", border: "1px solid #222", fontFamily: "sans-serif" },
  cardAdminBtns: { display: "flex", gap: 6 },
  iconBtn: { background: "none", border: "none", color: "#555", fontSize: 14, cursor: "pointer", padding: "4px 6px", transition: "color 0.2s" },
  addCard: { background: "#111", borderRadius: 12, border: "2px dashed #1e1e1e", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 280, cursor: "pointer", transition: "border-color 0.2s", gap: 8 },
  addCardPlus: { fontSize: 36, color: "#2a2a2a" },
  addCardLabel: { fontSize: 13, color: "#444", fontFamily: "sans-serif", letterSpacing: "0.05em" },
  // Detail
  detail: { maxWidth: 900, margin: "0 auto" },
  detailTopBar: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 },
  backBtn: { background: "none", border: "none", color: "#666", fontSize: 14, cursor: "pointer", padding: 0, fontFamily: "inherit", letterSpacing: "0.04em" },
  editBtn: { background: "none", border: "1px solid #333", color: "#888", fontSize: 13, cursor: "pointer", padding: "6px 14px", borderRadius: 6, fontFamily: "sans-serif" },
  hero: { position: "relative", height: 420, borderRadius: 16, overflow: "hidden", marginBottom: 32 },
  heroImg: { width: "100%", height: "100%", objectFit: "cover" },
  heroOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.88) 0%, rgba(0,0,0,0.2) 55%, transparent 100%)" },
  heroContent: { position: "absolute", bottom: 32, left: 32, right: 32 },
  detailTitle: { fontSize: 34, fontWeight: 400, margin: 0, lineHeight: 1.2, color: "#fff" },
  macrosRow: { display: "flex", gap: 12, marginBottom: 40, flexWrap: "wrap" },
  macroBox: { flex: 1, minWidth: 90, background: "#111", border: "1px solid #1e1e1e", borderRadius: 10, padding: "14px 18px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 },
  macroVal: { fontSize: 22, color: "#c8a96e" },
  macroKey: { fontSize: 11, color: "#555", letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "sans-serif" },
  detailBody: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 },
  sectionTitle: { fontSize: 11, letterSpacing: "0.18em", color: "#c8a96e", textTransform: "uppercase", fontWeight: 400, marginBottom: 24, borderBottom: "1px solid #1a1a1a", paddingBottom: 12, fontFamily: "sans-serif" },
  ingredientSec: { fontSize: 14, color: "#666", fontWeight: 400, marginBottom: 10, fontStyle: "italic" },
  ingredientList: { listStyle: "none", padding: 0, margin: "0 0 16px" },
  ingredientItem: { display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 8, fontSize: 16, lineHeight: 1.5 },
  ingredientDot: { color: "#c8a96e", fontSize: 9, marginTop: 7, flexShrink: 0 },
  stepList: { listStyle: "none", padding: 0, margin: 0 },
  stepItem: { display: "flex", gap: 16, marginBottom: 22, alignItems: "flex-start" },
  stepNum: { fontSize: 26, color: "#1e1e1e", fontWeight: 700, lineHeight: 1, flexShrink: 0, minWidth: 32 },
  stepText: { fontSize: 15, lineHeight: 1.75, color: "#bbb", paddingTop: 4 },
  // Planner
  plannerTitle: { fontSize: 11, letterSpacing: "0.18em", color: "#c8a96e", textTransform: "uppercase", fontWeight: 400, marginBottom: 32, fontFamily: "sans-serif" },
  plannerGrid: { display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 10 },
  dayCol: { display: "flex", flexDirection: "column", gap: 8 },
  dayHeader: { paddingBottom: 10, borderBottom: "1px solid #1a1a1a", marginBottom: 2 },
  dayName: { display: "block", fontSize: 13, color: "#f0ede8", letterSpacing: "0.06em" },
  dayCount: { display: "block", fontSize: 11, color: "#3a3a3a", fontFamily: "sans-serif", marginTop: 2 },
  emptyDay: { fontSize: 11, color: "#222", padding: "10px 0", fontFamily: "sans-serif" },
  plannerCard: { background: "#111", borderRadius: 8, overflow: "hidden", cursor: "pointer", border: "1px solid #1a1a1a", transition: "border-color 0.2s" },
  plannerImgWrap: { position: "relative", height: 80, overflow: "hidden" },
  plannerImg: { width: "100%", height: "100%", objectFit: "cover" },
  plannerImgOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 100%)" },
  plannerBody: { padding: "8px 10px 10px" },
  plannerName: { fontSize: 12, margin: "0 0 6px", lineHeight: 1.3, color: "#bbb" },
  // Modals
  modalOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 },
  modal: { background: "#111", border: "1px solid #1e1e1e", borderRadius: 16, padding: 32, width: "min(440px, 95vw)", boxShadow: "0 40px 100px rgba(0,0,0,0.8)" },
  modalTitle: { fontSize: 22, fontWeight: 400, margin: "0 0 6px", color: "#f0ede8" },
  modalSub: { fontSize: 14, color: "#555", margin: "0 0 24px", fontFamily: "sans-serif" },
  pinInput: { width: "100%", background: "#0d0d0d", border: "1px solid #2a2a2a", borderRadius: 8, padding: "12px 16px", fontSize: 24, color: "#f0ede8", textAlign: "center", letterSpacing: 8, boxSizing: "border-box", outline: "none", fontFamily: "sans-serif" },
  pinError: { color: "#e85a5a", fontSize: 13, textAlign: "center", margin: "8px 0 0", fontFamily: "sans-serif" },
  modalCancelBtn: { flex: 1, background: "none", border: "1px solid #2a2a2a", color: "#666", padding: "10px", borderRadius: 8, cursor: "pointer", fontFamily: "inherit", fontSize: 15 },
  modalConfirmBtn: { flex: 1, background: "#c8a96e", border: "none", color: "#0d0d0d", padding: "10px", borderRadius: 8, cursor: "pointer", fontFamily: "inherit", fontSize: 15, fontWeight: 600 },
  closeBtn: { background: "none", border: "none", color: "#555", fontSize: 20, cursor: "pointer", padding: 4 },
  // Editor
  editorHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 28px 16px", borderBottom: "1px solid #1a1a1a" },
  editorBody: { padding: "0 28px", overflowY: "auto" },
  editorFooter: { display: "flex", gap: 10, padding: "16px 28px", borderTop: "1px solid #1a1a1a" },
  editorSection: { paddingBottom: 24, marginBottom: 24, borderBottom: "1px solid #1a1a1a" },
  editorSectionTitle: { fontSize: 11, letterSpacing: "0.15em", color: "#c8a96e", textTransform: "uppercase", fontWeight: 400, marginBottom: 16, fontFamily: "sans-serif" },
  label: { display: "block", fontSize: 12, color: "#555", letterSpacing: "0.08em", marginBottom: 6, marginTop: 14, fontFamily: "sans-serif", textTransform: "uppercase" },
  input: { width: "100%", background: "#0d0d0d", border: "1px solid #1e1e1e", borderRadius: 8, padding: "10px 14px", fontSize: 15, color: "#f0ede8", boxSizing: "border-box", outline: "none", fontFamily: "inherit", marginBottom: 4, transition: "border-color 0.2s" },
  select: { width: "100%", background: "#0d0d0d", border: "1px solid #1e1e1e", borderRadius: 8, padding: "10px 14px", fontSize: 15, color: "#f0ede8", boxSizing: "border-box", outline: "none", fontFamily: "inherit" },
  checkGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 10 },
  checkLabel: { display: "flex", alignItems: "center", gap: 8, fontSize: 14, color: "#aaa", cursor: "pointer", fontFamily: "sans-serif" },
  ingredientBlock: { background: "#0d0d0d", borderRadius: 8, padding: 14, marginBottom: 12, border: "1px solid #1a1a1a" },
  imgPreview: { width: "100%", height: 140, objectFit: "cover", borderRadius: 8, marginTop: 8 },
  ghostBtn: { background: "none", border: "1px dashed #2a2a2a", color: "#555", padding: "7px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontFamily: "sans-serif", marginTop: 6, width: "100%" },
};
