export const INITIAL_RECIPES = [
  {
    id: "1",
    name: "Peruvian Style Chicken with Coconut Rice & Aji Verde",
    cuisine: "Peruvian",
    tags: ["High Protein"],
    type: "Main Course",
    schedule: ["Monday"],
    image: "https://www.daringgourmet.com/wp-content/uploads/2021/04/Peruvian-Chicken-1.jpg",
    ingredients: {
      "Chicken + Marinade": [
        "1.5 lb / 700g boneless chicken thighs",
        "4 garlic cloves, minced",
        "2 tbsp soy sauce",
        "2 tbsp fresh lime juice (1 lime)",
        "Olive oil",
        "Chili flakes to taste",
        "2 tsp brown sugar",
        "1 tsp ground cumin",
        "1 tbsp smoked paprika",
        "1 tsp dried oregano",
        "Salt and black pepper",
        "1–2 tbsp Aji Amarillo paste (optional)"
      ],
      "Aji Verde (Green Sauce)": [
        "1 packed cup / 30g fresh cilantro",
        "2–3 fresh jalapeños, seeded and ribs removed",
        "2–3 garlic cloves",
        "⅔ cup / 150g sour cream",
        "2 scallions (green part only)",
        "1 tbsp lime juice",
        "2 tbsp olive oil",
        "Salt and pepper to taste"
      ],
      "Coconut Rice": [
        "250g / 1¼ cup washed basmati rice (soaked 1 hour, drained)",
        "13.5 oz / 400ml coconut milk",
        "1 tsp salt"
      ],
      "To Serve": [
        "2–4 corn cobs (grilled or boiled)",
        "Fresh cilantro, chopped",
        "Lime wedges"
      ]
    },
    steps: [
      "Marinate the chicken — Mix all marinade ingredients with the chicken and let sit 20+ minutes.",
      "Cook the rice — Combine rice, coconut milk, and salt. Bring to a gentle boil, then cover and cook on low heat for 12–15 minutes. Let steam 10 minutes, then fluff.",
      "Make the aji verde — Blend all sauce ingredients until smooth, creamy, and bright green.",
      "Cook the chicken — Sear 5–7 min per side until golden and cooked through. Rest before slicing.",
      "Assemble — Serve chicken over coconut rice with aji verde, corn, cilantro, and lime wedges."
    ]
  },
  {
    id: "2",
    name: "Chipotle Honey Chicken Tacos",
    cuisine: "Mexican",
    tags: ["High Protein"],
    type: "Main Course",
    schedule: ["Tuesday"],
    image: "https://modernhoney.com/wp-content/uploads/2024/01/Chipotle-Chicken-Tacos-14-scaled.jpg",
    ingredients: {
      "Chipotle Honey Chicken": [
        "2 lbs (907g) raw boneless skinless chicken thighs",
        "3 chipotle peppers in adobo",
        "3 tbsp adobo sauce",
        "2 tbsp honey",
        "Juice of 2 limes",
        "5 garlic cloves",
        "1½ tbsp olive oil",
        "1 tsp salt",
        "½ tsp pepper"
      ],
      "For The Cheese Pull": [
        "2 cups reduced-fat mozzarella"
      ],
      "Tacos": [
        "6 low cal tortilla wraps",
        "Cilantro",
        "Pico de gallo"
      ],
      "Green Goddess Sauce": [
        "¾ cup (170g) nonfat Greek yogurt",
        "½ packed cup cilantro",
        "Juice of 2 limes",
        "¼ cup mild pickled jalapeño",
        "1 garlic clove",
        "Salt & pepper",
        "Splash of water"
      ]
    },
    steps: [
      "Blend chipotle peppers, adobo sauce, honey, lime juice, garlic, olive oil, salt and pepper into a smooth marinade.",
      "Coat chicken thighs thoroughly in the marinade and let sit for at least 20 minutes.",
      "Sear chicken in a hot pan 5–7 min per side until cooked through and caramelized. Rest, then slice.",
      "Blend all green goddess sauce ingredients until completely smooth.",
      "Warm tortillas, load with sliced chicken, top with mozzarella, pico de gallo, cilantro, and green goddess sauce."
    ],
    macros: { calories: 342, protein: 34, carbs: 11, fat: 18 }
  }
];

export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export const CUISINE_OPTIONS = ["Peruvian", "Mexican", "Italian", "Asian", "American", "Mediterranean", "Middle Eastern", "Other"];

export const TAG_OPTIONS = ["High Protein", "Quick", "Meal Prep", "Vegetarian", "Vegan", "Low Fat", "Make Ahead", "No Cook"];

export const TYPE_OPTIONS = ["Main Course", "Breakfast", "Appetizer", "Side Dish", "Dessert", "Snack", "Beverage", "Other"];

export const CUISINE_COLORS = {
  Peruvian: "#e8825a",
  Mexican: "#e85a5a",
  Italian: "#5ab85a",
  Asian: "#e8c85a",
  American: "#5a8ae8",
  Mediterranean: "#a05ae8",
  "Middle Eastern": "#e85ab8",
  Other: "#888"
};

export const TAG_COLORS = {
  "High Protein": "#c0392b",
  "Quick": "#2980b9",
  "Meal Prep": "#d35400",
  "Vegetarian": "#27ae60",
  "Vegan": "#16a085",
  "Low Fat": "#8e44ad",
  "Make Ahead": "#f39c12",
  "No Cook": "#7f8c8d"
};
